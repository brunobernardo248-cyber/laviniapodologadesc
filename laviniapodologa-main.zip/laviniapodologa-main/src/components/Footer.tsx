const Footer = () => (
  <footer className="py-8 px-6 bg-foreground text-primary-foreground/60 text-center text-sm pb-24">
    <p className="font-display text-primary-foreground/80 text-lg mb-2">👣 Lavínia Podóloga</p>
    <p>© {new Date().getFullYear()} — Todos os direitos reservados</p>
  </footer>
);

export default Footer;
