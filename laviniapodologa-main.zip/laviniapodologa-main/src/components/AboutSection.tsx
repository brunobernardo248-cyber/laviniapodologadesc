import { MapPin, Clock, Phone } from "lucide-react";

const AboutSection = () => (
  <section className="py-20 px-6 bg-secondary/50">
    <div className="max-w-3xl mx-auto text-center">
      <p className="text-primary text-sm tracking-[0.2em] uppercase mb-2">Sobre</p>
      <h2 className="font-display text-3xl md:text-4xl font-semibold text-foreground mb-6">
        Lavínia Podóloga
      </h2>
      <p className="text-muted-foreground leading-relaxed mb-12 max-w-xl mx-auto">
        Profissional dedicada ao cuidado dos seus pés, com atendimento humanizado e técnicas atualizadas para garantir seu conforto e saúde.
      </p>

      <div className="grid sm:grid-cols-3 gap-6">
        {[
          { icon: MapPin, label: "Localização", value: "Consulte via WhatsApp" },
          { icon: Clock, label: "Horário", value: "Seg - Sáb" },
          { icon: Phone, label: "Contato", value: "(32) 99801-6614" },
        ].map((item) => (
          <div key={item.label} className="flex flex-col items-center gap-2 p-6 rounded-xl bg-card border border-border">
            <item.icon className="w-5 h-5 text-primary mb-1" />
            <span className="text-xs uppercase tracking-wider text-muted-foreground">{item.label}</span>
            <span className="text-sm font-medium text-foreground">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  </section>
);

export default AboutSection;
